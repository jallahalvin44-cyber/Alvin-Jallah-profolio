// Interactive JS: filters, theme toggle, copy email mock, and simple animations
document.addEventListener('DOMContentLoaded', () => {
  // year
  document.getElementById('year').textContent = new Date().getFullYear();

  // theme button: toggle a pulsing class for fun
  const themeBtn = document.getElementById('themeBtn');
  themeBtn.addEventListener('click', () => {
    document.body.classList.toggle('pulse');
    themeBtn.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.08)' }, { transform: 'scale(1)' }], { duration: 420, easing: 'ease-out' });
  });

  // project filter
  const filters = document.querySelectorAll('.filter');
  const projects = document.querySelectorAll('.project');
  filters.forEach(f => f.addEventListener('click', () => {
    filters.forEach(b => b.classList.remove('active'));
    f.classList.add('active');
    const type = f.dataset.filter;
    projects.forEach(p => {
      if (type === 'all' || p.dataset.type === type) p.style.display = 'block';
      else p.style.display = 'none';
    });
  }));

  // mouse parallax highlight for project cards
  document.querySelectorAll('.project').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const r = card.getBoundingClientRect();
      const mx = ((e.clientX - r.left) / r.width) * 100;
      const my = ((e.clientY - r.top) / r.height) * 100;
      card.style.setProperty('--mx', mx + '%');
      card.style.setProperty('--my', my + '%');
    });
  });

  // contact form (mock) and copy email
  document.getElementById('contactForm').addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Thanks! Message sent (demo mode). I will get back to you.');
    e.target.reset();
  });
  document.getElementById('copyEmail').addEventListener('click', () => {
    navigator.clipboard?.writeText('alvin@example.com').then(() => {
      const original = document.getElementById('copyEmail').textContent;
      document.getElementById('copyEmail').textContent = 'Copied!';
      setTimeout(()=> document.getElementById('copyEmail').textContent = original, 1400);
    }).catch(()=> alert('Copy not supported in this browser.'));
  });

  // subtle entry animation for hero
  document.querySelector('.hero').animate([{ opacity:0, transform:'translateY(12px)' }, { opacity:1, transform:'translateY(0)'}], { duration:600, easing:'cubic-bezier(.2,.9,.2,1)' });

  console.log('Portfolio (dark + colorful) ready — enjoy!');
});
